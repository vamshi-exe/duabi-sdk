//
//  CCAvenueUaeVertical.h
//  CCAvenueUaeVertical
//
//  Created by Ram Mhapasekar on 21/10/20.
//

#import <Foundation/Foundation.h>

//! Project version number for CCAvenueUaeVertical.
FOUNDATION_EXPORT double CCAvenueUaeVerticalVersionNumber;

//! Project version string for CCAvenueUaeVertical.
FOUNDATION_EXPORT const unsigned char CCAvenueUaeVerticalVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CCAvenueUaeVertical/PublicHeader.h>


